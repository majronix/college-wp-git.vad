<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="format-detection" content="telephone=no">
<meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no, maximum-scale=1">
<title>DAGAZ - Home</title>

<!-- Fonts google 
<link href='https://fonts.googleapis.com/css?family=Open+Sans:400,600,300,300italic,400italic,600italic,700,700italic,800,800italic&subset=latin,latin-ext,cyrillic,cyrillic-ext' rel='stylesheet' type='text/css'>   

<link href='https://fonts.googleapis.com/css?family=Roboto+Slab:300,700&subset=latin,latin-ext,cyrillic,cyrillic-ext' rel='stylesheet' type='text/css'>   -->

<link rel="stylesheet" type="text/css" href="css/style.css" />		
<!--[if lt IE 9]><script src="js/html5.js"></script><![endif]-->