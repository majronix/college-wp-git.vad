<div class="calendar_wrap">

	<div class="calendar__date">2016</div>

	<div class="rent_calendar">
		<div class="rent_calendar_head clearfix">
			<a href="" class="navigation _middle _left"></a>
			<a href="" class="navigation _middle _right"></a>

			<div class="rent_calendar_head__date">листопад</div>
			
		</div>
		<!--head-->

		<div class="rent_calendar_content clearfix">

			<div class="rent_calendar_content_head">
				<a href="" class="rent_calendar__day"><span>Пн</span></a>
				<a href="" class="rent_calendar__day"><span>Вт</span></a>
				<a href="" class="rent_calendar__day"><span>Ср</span></a>
				<a href="" class="rent_calendar__day"><span>Чт</span></a>
				<a href="" class="rent_calendar__day"><span>Пт</span></a>
				<a href="" class="rent_calendar__day"><span>Сб</span></a>
				<a href="" class="rent_calendar__day"><span>Вс</span></a>
			</div>
			
			<a href="" class="rent_calendar__day"><span></span></a>
			<a href="" class="rent_calendar__day"><span></span></a>
			<a href="" class="rent_calendar__day"><span></span></a>
			<a href="" class="rent_calendar__day"><span></span></a>
			<a href="" class="rent_calendar__day"><span></span></a>
			<a href="" class="rent_calendar__day active"><span>1</span></a>
			<a href="" class="rent_calendar__day active"><span>2</span></a>
			<a href="" class="rent_calendar__day"><span>3</span></a>
			<a href="" class="rent_calendar__day"><span>4</span></a>
			<a href="" class="rent_calendar__day"><span>5</span></a>
			<a href="" class="rent_calendar__day"><span>6</span></a>
			<a href="" class="rent_calendar__day"><span>7</span></a>
			<a href="" class="rent_calendar__day"><span>8</span></a>
			<a href="" class="rent_calendar__day"><span>9</span></a>
			<a href="" class="rent_calendar__day"><span>10</span></a>
			<a href="" class="rent_calendar__day"><span>11</span></a>
			<a href="" class="rent_calendar__day"><span>12</span></a>
			<a href="" class="rent_calendar__day"><span>13</span></a>
			<a href="" class="rent_calendar__day"><span>14</span></a>
			<a href="" class="rent_calendar__day active_day"><span>15</span></a>
			<a href="" class="rent_calendar__day"><span>16</span></a>
			<a href="" class="rent_calendar__day"><span>17</span></a>
			<a href="" class="rent_calendar__day"><span>18</span></a>
			<a href="" class="rent_calendar__day"><span>19</span></a>
			<a href="" class="rent_calendar__day"><span>20</span></a>
			<a href="" class="rent_calendar__day"><span>21</span></a>
			<a href="" class="rent_calendar__day"><span>22</span></a>
			<a href="" class="rent_calendar__day"><span>23</span></a>
			<a href="" class="rent_calendar__day"><span>24</span></a>
			<a href="" class="rent_calendar__day"><span>25</span></a>
			<a href="" class="rent_calendar__day"><span>26</span></a>
			<a href="" class="rent_calendar__day"><span>27</span></a>
			<a href="" class="rent_calendar__day"><span>28</span></a>
			<a href="" class="rent_calendar__day"><span>29</span></a>
			<a href="" class="rent_calendar__day"><span>30</span></a>
			<a href="" class="rent_calendar__day"><span>31</span></a>
		</div>
		<!--calendar-content-->					

	</div>
	<!-- rent_calendar -->									

</div>
<!-- calendar_wrap -->